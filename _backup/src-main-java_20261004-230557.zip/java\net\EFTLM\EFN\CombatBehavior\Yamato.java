package net.EFTLM.EFN.CombatBehavior;

import com.hm.efn.gameasset.EFNAnimations;
import com.hm.efn.gameasset.animations.EFNYamatoAnimations;
import net.EFTLM.EF.Animation.BehaviorsBuild;
import yesman.epicfight.world.capabilities.entitypatch.HumanoidMobPatch;
import yesman.epicfight.world.entity.ai.goal.CombatBehaviors;
public class Yamato {
    public static CombatBehaviors.Builder<HumanoidMobPatch<?>> getInstance() {
        return EFNCompatHolder.Instance;
    }
    private static class EFNCompatHolder {
        static final CombatBehaviors.Builder<HumanoidMobPatch<?>> Instance;
        static {
            Instance = CombatBehaviors.<HumanoidMobPatch<?>>builder()
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(20)
                                    .weight(110.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO1)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO2)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO3)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_EXTEND_AUTO3)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_EXTEND_AUTO4)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_EXTEND_AUTO5)
                                                    .withinDistance(0.0D, 4.0D))
                    )
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(45)
                                    .weight(80.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_FLARECUT_RISING)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_ORBIT_1)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_ORBIT_2)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_HELMBREAKER)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO1)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO2)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO3)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_FLARECUT)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_EXTEND_AUTO3)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_EXTEND_AUTO4)
                                                    .withinDistance(0.0D, 4.0D))
                    )
                    // ② 分离斩连段 → 挑空 → 落斩
                    //    原型：玩家的第二套地面连段（Combo B），收尾挑空接空中落斩，
                    //    距离放宽到 3.5 会互相抢出招，所以起手距离比 ① 更近。
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(45)
                                    .weight(80.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_DIVORCE_AUTO1)
                                                    .withinDistance(0.0D, 3.5D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_DIVORCE_AUTO2)
                                                    .withinDistance(0.0D, 3.5D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_DIVORCE_AUTO3)
                                                    .withinDistance(0.0D, 3.5D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_FLARECUT_RISING)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_HELMBREAKER)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_FLARECUT)
                                                    .withinDistance(0.0D, 4.0D))
                    )
                    // ③ 挑空 → 空中连斩（Aerial Rave）→ 环斩 → 俯冲收尾
                    //    原型：玩家最经典的「挑空起手 → 空中连段 → 落地」循环。
                    //    FLARECUT_RISING 是升龙挑空，会把人带起来，后面的空中招式才成立。
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(70)
                                    .weight(60.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_FLARECUT_RISING)
                                                    .withinDistance(0.0D, 3.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_AERIALRAVE_AUTO1)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_AERIALRAVE_AUTO2)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_AERIALRAVE_AUTO3)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_ORBIT_1)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_ORBIT_2)
                                                    .withinDistance(0.0D, 4.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_KILLERBEE)
                                                    .withinDistance(0.0D, 4.0D))
                    )
                    // ④ 疾走斩突进 → 地面三连 → 践踏
                    //    原型：玩家用疾走斩（Rapid Slash）拉近距离后立刻接地面连段，
                    //    只在 4 格以外起手，近距离不会和 ①② 抢。
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(35)
                                    .weight(70.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_REPAIDSLASH_MOB)
                                                    .withinDistance(4.0D, 16.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO1)
                                                    .withinDistance(0.0D, 4.5D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO2)
                                                    .withinDistance(0.0D, 4.5D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_NORMAL_AUTO3)
                                                    .withinDistance(0.0D, 4.5D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_STOMP)
                                                    .withinDistance(0.0D, 4.5D))
                    )
                    // ⑤ 次元斩三连 → 火山蓄力收尾
                    //    原型：玩家在中距离用手感最好的「完美次元斩」连放，最后接火山。
                    //    只用 4 格以外的距离起手，避免贴脸放远程斩。
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(60)
                                    .weight(70.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_JUDEMENCUT_JUST_MOB)
                                                    .withinDistance(4.0D, 14.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_JUDEMENCUT_JUST_MOB)
                                                    .withinDistance(0.0D, 14.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_JUDEMENCUT_JUST_MOB)
                                                    .withinDistance(0.0D, 14.0D))
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .animationBehavior(EFNYamatoAnimations.YAMATO_REPAIDSLASH_MOB)
                                                    .withinDistance(0.0D, 14.0D))
                    )
                    // ⑥ 满层大招「次元斩决」
                    //    层数攒满就放：权重给得比其他串高得多，一旦满层基本会在下一次出招机会释放。
                    .newBehaviorSeries(
                            CombatBehaviors.BehaviorSeries.<HumanoidMobPatch<?>>builder()
                                    .cooldown(20)
                                    .weight(300.0F)
                                    .canBeInterrupted(false)
                                    .looping(false)
                                    .nextBehavior(
                                            CombatBehaviors.Behavior.<HumanoidMobPatch<?>>builder()
                                                    .custom(Patch -> BehaviorsBuild.hasStack(Patch,BehaviorsBuild.getMaxStack(Patch)))
                                                    .behavior(Patch -> {
                                                            Patch.playAnimationSynchronized(EFNAnimations.DMC5_V_JC, 0F);
                                                            BehaviorsBuild.setStack(Patch,0);
                                                    })
                                                    .withinDistance(0.0D, 24.0D))
                    );
        }
    }
}
