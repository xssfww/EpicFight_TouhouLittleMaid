package net.EFTLM.EFN.Skill;

import com.github.tartaricacid.touhoulittlemaid.api.event.MaidTickEvent;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.hm.efn.EFN;
import com.hm.efn.gameasset.EFNEnchantment;
import com.hm.efn.item.custom.YamatoItem;
import net.EFTLM.EF.API.Event.MaidHurtTargetEvent;
import net.EFTLM.EF.API.Event.MaidKilledEvent;
import net.EFTLM.EF.API.Event.MaidSkillInitEvent;
import net.EFTLM.EF.Capability.MaidPatch;
import net.EFTLM.EF.Compat.EFNCompat;
import net.EFTLM.EF.Skill.MaidSkill;
import net.EFTLM.EF.Skill.MaidSkillBuilder;
import net.EFTLM.EF.Skill.MaidSkillDataKeys;
import net.EFTLM.EF.Skill.MaidSkillDataManager;
import net.EFTLM.EF.Skill.WeaponInnate.WeaponInnateSkill;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
/**
 * 阎魔刀（DMC 新鬼泣）的武器固有技能。
 * <p>
 * 女仆没有按键输入，因此原本写在 {@code CombatBehavior} 里的「无门阵 / 急袭幻影剑」改为在命中时
 * <b>概率增援</b>：每次造成伤害后按 {@code reinforce_chance} 掷骰，在层数足够、冷却结束的幻影剑技巧中
 * 按权重随机挑选一个释放，并扣除对应层数。
 * <p>
 * 可用的技巧与 EFN 阎魔刀技能（{@code com.hm.efn.skill.weapon_innate.YamatoInnate}）一一对应：
 * <ul>
 *   <li>急袭：{@code BlastSummonedSwordEntity}，前进的一列幻影剑</li>
 *   <li>暴雨：{@code SummonedSwordEntity_In}，在目标腰间成环并施加凋零</li>
 *   <li>五月雨：{@code HeavyRainSwordEntity}，降下剑雨并硬直目标（EFN 中由「五月雨」附魔替换无门阵）</li>
 *   <li>无门阵：{@code SummonedSwordEntity_Out}，腰间剑阵，持续时间即冷却</li>
 * </ul>
 * 层数消耗与冷却对齐 EFN；参数可在 {@code data/ef_tlm/maid_skill/yamato_innate.json} 中调整。
 * 满层大招「次元斩决」仍由 CombatBehavior 负责，在层数满时释放。
 */
public class YamatoSkill extends WeaponInnateSkill {
    // ==================== 可调参数（data/ef_tlm/maid_skill/yamato_innate.json） ====================
    /** 每次命中触发幻影剑增援的概率。 */
    private static final String PARAM_REINFORCE_CHANCE = "reinforce_chance";
    /** 五月雨是否要求阎魔刀附有 EFN 的「五月雨」附魔。 */
    private static final String PARAM_REQUIRE_HEAVY_RAIN_ENCHANTMENT = "require_heavy_rain_enchantment";
    private static final float DEFAULT_REINFORCE_CHANCE = 0.15F;
    private static final boolean DEFAULT_REQUIRE_HEAVY_RAIN_ENCHANTMENT = false;
    // ==================== 各类幻影剑技巧的消耗 / 冷却 / 权重 ====================
    /** 急袭：1 层，冷却对齐 EFN 的 20 tick。 */
    private static final int BLAST_COST = 1;
    private static final int BLAST_COOLDOWN = 20;
    private static final int BLAST_WEIGHT = 35;
    /** 暴雨：1 层；EFN 未设冷却，这里按女仆的攻击节奏补 40 tick 防止刷屏。 */
    private static final int SWORD_RAIN_COST = 1;
    private static final int SWORD_RAIN_COOLDOWN = 40;
    private static final int SWORD_RAIN_WEIGHT = 25;
    /** 五月雨：3 层，冷却在 EFN 的 30 tick 基础上略放宽。 */
    private static final int HEAVY_RAIN_COST = 3;
    private static final int HEAVY_RAIN_COOLDOWN = 60;
    private static final int HEAVY_RAIN_WEIGHT = 25;
    /** 无门阵：5 层，持续/冷却对齐 EFN 的 600 tick。 */
    private static final int FORMATION_COST = 5;
    private static final int FORMATION_WEIGHT = 15;
    private float reinforceChance = DEFAULT_REINFORCE_CHANCE;
    private boolean requireHeavyRainEnchantment = DEFAULT_REQUIRE_HEAVY_RAIN_ENCHANTMENT;
    public YamatoSkill(MaidSkillBuilder<? extends MaidSkill> builder) {
        super(builder);
    }
    @Override
    public void setParams(CompoundTag parameters) {
        super.setParams(parameters);
        if (parameters.contains(PARAM_REINFORCE_CHANCE)) {
            this.reinforceChance = Mth.clamp(parameters.getFloat(PARAM_REINFORCE_CHANCE), 0.0F, 1.0F);
        }
        if (parameters.contains(PARAM_REQUIRE_HEAVY_RAIN_ENCHANTMENT)) {
            this.requireHeavyRainEnchantment = parameters.getBoolean(PARAM_REQUIRE_HEAVY_RAIN_ENCHANTMENT);
        }
    }
    @Override
    public void onInit(MaidSkillInitEvent event) {
        super.onInit(event);
        event.registerData(this, MaidSkillDataKeys.YAMATO_FORMATION_TIME);
        event.registerData(this, MaidSkillDataKeys.YAMATO_BLAST_COOLDOWN);
        event.registerData(this, MaidSkillDataKeys.YAMATO_SWORD_RAIN_COOLDOWN);
        event.registerData(this, MaidSkillDataKeys.YAMATO_HEAVY_RAIN_COOLDOWN);
    }
    @Override
    public void onMaidTick(MaidTickEvent event,MaidPatch<?> patch) {
        super.onMaidTick(event,patch);
        if (patch == null) return;
        tickCooldown(patch, MaidSkillDataKeys.YAMATO_FORMATION_TIME);
        tickCooldown(patch, MaidSkillDataKeys.YAMATO_BLAST_COOLDOWN);
        tickCooldown(patch, MaidSkillDataKeys.YAMATO_SWORD_RAIN_COOLDOWN);
        tickCooldown(patch, MaidSkillDataKeys.YAMATO_HEAVY_RAIN_COOLDOWN);
    }
    @Override
    public void onHurtTargetPost(MaidHurtTargetEvent.Post event) {
        super.onHurtTargetPost(event);
        MaidPatch<?> MaidPatch = event.getMaidPatch();
        if (MaidPatch == null) return;
        EntityMaid Maid = MaidPatch.getOriginal();
        if (!(Maid.level() instanceof ServerLevel)) return;
        ItemStack item = Maid.getMainHandItem();
        if (!(item.getItem() instanceof YamatoItem)) return;
        CompoundTag tag = item.getOrCreateTag();
        float totalDamage = YamatoItem.getTotalDamage(item);
        tag.putFloat("TotalDamage",totalDamage + event.getAmount());
        tryReinforceSword(MaidPatch, item, event.getTarget());
    }
    @Override
    public void onKillTarget(MaidKilledEvent event) {
        MaidPatch<?> MaidPatch = event.getMaidPatch();
        EntityMaid Maid = MaidPatch.getOriginal();
        ItemStack item = Maid.getMainHandItem();
        if (item.getItem() instanceof YamatoItem) {
            CompoundTag tag = item.getOrCreateTag();
            int currentCount = YamatoItem.getKillCount(item);
            tag.putInt("KillCount", currentCount + 1);
        }
    }
    /**
     * 概率幻影剑增援。
     * <p>
     * 命中后先按 {@link #reinforceChance} 掷骰；通过后把「层数足够 + 冷却结束」的技巧按权重组成池子，
     * 随机抽一个释放并扣除层数、写入冷却。没有可用技巧时什么也不做，因此不会阻挡满层大招。
     */
    private void tryReinforceSword(MaidPatch<?> patch, ItemStack item, LivingEntity target) {
        EntityMaid maid = patch.getOriginal();
        if (maid.getRandom().nextFloat() >= this.reinforceChance) return;
        Integer stackValue = patch.getDataValue(this, MaidSkillDataKeys.STACK);
        int stack = stackValue == null ? 0 : stackValue;
        if (stack <= 0) return;
        boolean hasTarget = target != null && target.isAlive();
        boolean canBlast = hasTarget && stack >= BLAST_COST && isCooldownReady(patch, MaidSkillDataKeys.YAMATO_BLAST_COOLDOWN);
        boolean canSwordRain = hasTarget && stack >= SWORD_RAIN_COST && isCooldownReady(patch, MaidSkillDataKeys.YAMATO_SWORD_RAIN_COOLDOWN);
        boolean canHeavyRain = hasTarget && stack >= HEAVY_RAIN_COST && isCooldownReady(patch, MaidSkillDataKeys.YAMATO_HEAVY_RAIN_COOLDOWN)
                && (!this.requireHeavyRainEnchantment || item.getEnchantmentLevel(EFNEnchantment.YAMATO_HEAVY_RAIN.get()) > 0);
        boolean canFormation = stack >= FORMATION_COST && EFNCompat.canSummonAtWaist(patch);
        int totalWeight = (canBlast ? BLAST_WEIGHT : 0) + (canSwordRain ? SWORD_RAIN_WEIGHT : 0)
                + (canHeavyRain ? HEAVY_RAIN_WEIGHT : 0) + (canFormation ? FORMATION_WEIGHT : 0);
        if (totalWeight <= 0) return;
        int roll = maid.getRandom().nextInt(totalWeight);
        if (canBlast) {
            if (roll < BLAST_WEIGHT) {
                EFNCompat.summonBlastSword(patch);
                consumeStack(patch, stack, BLAST_COST);
                setCooldown(patch, MaidSkillDataKeys.YAMATO_BLAST_COOLDOWN, BLAST_COOLDOWN);
                return;
            }
            roll -= BLAST_WEIGHT;
        }
        if (canSwordRain) {
            if (roll < SWORD_RAIN_WEIGHT) {
                EFNCompat.summonSwordRain(patch);
                consumeStack(patch, stack, SWORD_RAIN_COST);
                setCooldown(patch, MaidSkillDataKeys.YAMATO_SWORD_RAIN_COOLDOWN, SWORD_RAIN_COOLDOWN);
                return;
            }
            roll -= SWORD_RAIN_WEIGHT;
        }
        if (canHeavyRain) {
            if (roll < HEAVY_RAIN_WEIGHT) {
                EFNCompat.summonHeavyRain(patch);
                consumeStack(patch, stack, HEAVY_RAIN_COST);
                setCooldown(patch, MaidSkillDataKeys.YAMATO_HEAVY_RAIN_COOLDOWN, HEAVY_RAIN_COOLDOWN);
                return;
            }
        }
        if (canFormation) {
            // summonAtWaist 内部会写入 YAMATO_FORMATION_TIME，作为剑阵的持续时间与冷却
            EFNCompat.summonAtWaist(patch);
            consumeStack(patch, stack, FORMATION_COST);
        }
    }
    private void consumeStack(MaidPatch<?> patch, int currentStack, int cost) {
        patch.setData(this, MaidSkillDataKeys.STACK, Math.max(currentStack - cost, 0));
    }
    private void setCooldown(MaidPatch<?> patch, MaidSkillDataManager.SkillDataKey<Integer> key, int ticks) {
        patch.setData(this, key, ticks);
    }
    /** 冷却读数为空或已归零时可用。 */
    private boolean isCooldownReady(MaidPatch<?> patch, MaidSkillDataManager.SkillDataKey<Integer> key) {
        Integer time = patch.getDataValue(this, key);
        return time == null || time <= 0;
    }
    private void tickCooldown(MaidPatch<?> patch, MaidSkillDataManager.SkillDataKey<Integer> key) {
        Integer time = patch.getDataValue(this, key);
        if (time == null) return;
        if (time > 0) {
            patch.setData(this, key, time - 1);
        }
    }
    @Override
    public ResourceLocation getIcon() {
        return ResourceLocation.fromNamespaceAndPath(EFN.MODID, "textures/item/yamato_dmc4.png");
    }
}
