package net.EFTLM.EF.API.Event;

import net.EFTLM.EF.API.AbstractMaidEvent;
import net.EFTLM.EF.Capability.MaidPatch;
import net.EFTLM.EF.Skill.MaidSkill;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.eventbus.api.Cancelable;
/**
 * 女仆遗忘（移除）某个已学技能时投递。
 * <p>
 * 该事件可取消：监听者调用 {@link #setCanceled(boolean)} 即可阻止本次遗忘。
 * <p>
 * 核心监听器在事件未被取消时执行两件事：
 * <ol>
 *   <li>把技能从女仆的已学列表中移除；</li>
 *   <li>调用 {@link #removeData()} 清除该技能的数据。</li>
 * </ol>
 * <p>
 * 注意：武器固有技能（{@code WeaponInnateSkill}）由手持武器自动授予，
 * 界面上不会提供遗忘入口，服务端也不会移除。
 */
@Cancelable
public class MaidSkillRemoveEvent extends AbstractMaidEvent {
    private final MaidSkill skill;
    public MaidSkillRemoveEvent(MaidPatch<?> MaidPatch, MaidSkill skill) {
        super(MaidPatch);
        this.skill = skill;
    }
    public MaidSkill getSkill() {
        return this.skill;
    }
    public ResourceLocation getSkillName() {
        return this.skill == null ? null : this.skill.getRegistryName();
    }
    /**
     * 只清除被遗忘的那个技能的数据（{@link MaidPatch#removeData(MaidSkill)}），
     * 不会影响该女仆身上其他技能的数据。
     */
    public void removeData() {
        MaidPatch<?> MaidPatch = this.getMaidPatch();
        if (MaidPatch != null && this.skill != null) {
            MaidPatch.removeData(this.skill);
        }
    }
}
