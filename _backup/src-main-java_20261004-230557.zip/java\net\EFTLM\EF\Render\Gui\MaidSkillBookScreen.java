package net.EFTLM.EF.Render.Gui;

import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import com.mojang.blaze3d.platform.Window;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexSorting;
import net.EFTLM.EF.Capability.MaidPatch;
import net.EFTLM.EF.Network.Packet.Server.ForgetMaidSkillPacket;
import net.EFTLM.EF.Network.PacketSend;
import net.EFTLM.EF.Skill.MaidSkill;
import net.EFTLM.EF.Skill.WeaponInnate.WeaponInnateSkill;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.ObjectSelectionList;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.ForgeHooksClient;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import yesman.epicfight.main.EpicFightMod;
import yesman.epicfight.world.capabilities.EpicFightCapabilities;
import javax.annotation.Nullable;
import java.util.List;
public class MaidSkillBookScreen extends Screen {
    protected final MaidSkill Skill;
    protected final Screen ParentScreen;
    protected final int MaidId;
    protected final MaidSkillBookScreen.SkillTooltipList skillTooltipList;
    protected double customScale;
    private static final ResourceLocation SKILLBOOK_BACKGROUND = EpicFightMod.identifier("textures/gui/screen/skillbook.png");
    public MaidSkillBookScreen(MaidSkill Skill, Screen ParentScreen) {
        this(Skill, ParentScreen, -1);
    }
    public MaidSkillBookScreen(MaidSkill Skill, Screen ParentScreen, int MaidId) {
        super(Component.empty());
        this.Skill = Skill;
        this.ParentScreen = ParentScreen;
        this.MaidId = MaidId;
        this.skillTooltipList = new SkillTooltipList(Minecraft.getInstance(), 0, 0, 0, 0, 9);
        List<FormattedCharSequence> list = Minecraft.getInstance().font.split(this.Skill.getDesc(this.resolveMaidPatch()), 148);
        list.forEach(skillTooltipList::add);
    }
    /**
     * 解析本界面关联的女仆补丁，供 {@link MaidSkill#getDesc(MaidPatch)} 带入 {@code %s} 变量。
     *
     * @return 对应的补丁；无女仆上下文（技能书道具打开）或解析不到时返回 {@code null}
     */
    @Nullable
    protected MaidPatch<?> resolveMaidPatch() {
        if (this.MaidId < 0) return null;
        Level level = Minecraft.getInstance().level;
        if (level == null) return null;
        Entity entity = level.getEntity(this.MaidId);
        if (!(entity instanceof EntityMaid maid)) return null;
        return EpicFightCapabilities.getEntityPatch(maid, MaidPatch.class);
    }
    @Override
    protected void init() {
        Window window = Minecraft.getInstance().getWindow();
        if (window.getGuiScaledHeight() < 270 && window.getGuiScale() > 1.0) {
            this.customScale = window.getGuiScale() - 1.0;
            this.width = (int)((double)window.getWidth() / this.customScale);
            this.height = (int)((double)window.getHeight() / this.customScale);
        } else {
            this.customScale = window.getGuiScale();
        }
        this.skillTooltipList.updateSize(210, 400, this.height / 2 - 100, (this.height + 80) / 2);
        this.skillTooltipList.setLeftPos(this.width / 2 - 40);
        this.addRenderableWidget(this.skillTooltipList);
        if (this.canForget()) {
            this.addRenderableWidget(new ForgetButton(Button.builder(Component.translatable("gui.ef_tlm.button.forget_skill"), button -> this.forgetSkill())
                    .pos(this.width / 2 + 54, this.height / 2 + 90)
                    .size(80, 20)));
        }
    }
    /**
     * 是否提供遗忘入口，需同时满足：
     * <ul>
     *   <li>存在女仆上下文（{@link #MaidId} &gt;= 0），即从女仆技能界面进入，
     *       而不是玩家直接用技能书道具打开；</li>
     *   <li>该技能不是武器固有技能——武器固有技能由手持武器自动授予，
     *       给出遗忘入口没有意义，因此直接不显示。</li>
     * </ul>
     */
    protected boolean canForget() {
        if (this.MaidId < 0 || this.Skill == null) return false;
        return !(this.Skill instanceof WeaponInnateSkill);
    }
    /** 请求服务端遗忘该技能，然后返回上一级界面。 */
    protected void forgetSkill() {
        if (!this.canForget()) return;
        PacketSend.sendToServer(new ForgetMaidSkillPacket(this.MaidId, this.Skill.getRegistryName()));
        this.onClose();
    }
    public void render(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.render(guiGraphics, mouseX, mouseY, partialTicks, false);
    }
    @SuppressWarnings("UnstableApiUsage")
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks, boolean asBackground) {
        guiGraphics.pose().pushPose();
        Window window = Minecraft.getInstance().getWindow();
        double originalScale = window.getGuiScale();
        if (originalScale != this.customScale) {
            window.setGuiScale(this.customScale);
            Matrix4f matrix4f = (new Matrix4f()).setOrtho(0.0F, (float)((double)window.getWidth() / window.getGuiScale()), (float)((double)window.getHeight() / window.getGuiScale()), 0.0F, 1000.0F, ForgeHooksClient.getGuiFarPlane());
            RenderSystem.setProjectionMatrix(matrix4f, VertexSorting.ORTHOGRAPHIC_Z);
        }
        if (!asBackground) {
            this.renderBackground(guiGraphics);
        }
        int posX = (this.width - 284) / 2;
        int posY = (this.height - 165) / 2;
        RenderSystem.setShader(GameRenderer::getPositionTexColorShader);
        guiGraphics.blit(SKILLBOOK_BACKGROUND, this.width / 2 - 192, this.height / 2 - 140, 384, 279, 0.0F, 0.0F, 256, 186, 256, 256);
        guiGraphics.pose().pushPose();
        RenderSystem.enableBlend();
        guiGraphics.blit(this.Skill.getIcon(), this.width / 2 - 122, this.height / 2 - 99, 68, 68, 0.0F, 0.0F, 128, 128, 128, 128);
        RenderSystem.disableBlend();
        String skillName = Skill.getTitle().getString();
        int width = this.font.width(skillName);
        guiGraphics.drawString(this.font, skillName, posX + 56 - width / 2, posY + 75, 0, false);
        super.render(guiGraphics, (int)((double)mouseX * originalScale / this.customScale), (int)((double)mouseY * originalScale / this.customScale), partialTicks);
        if (asBackground) {
            this.renderBackground(guiGraphics);
        }
        guiGraphics.pose().popPose();
        if (originalScale != this.customScale) {
            window.setGuiScale(originalScale);
            Matrix4f matrix4f = (new Matrix4f()).setOrtho(0.0F, (float)((double)window.getWidth() / window.getGuiScale()), (float)((double)window.getHeight() / window.getGuiScale()), 0.0F, 1000.0F, ForgeHooksClient.getGuiFarPlane());
            RenderSystem.setProjectionMatrix(matrix4f, VertexSorting.ORTHOGRAPHIC_Z);
        }
    }
    @Override
    public void onClose() {
        if (this.ParentScreen != null) {
            if (this.minecraft != null) {
                this.minecraft.setScreen(this.ParentScreen);
            }
        } else {
            super.onClose();
        }
    }
    @Override
    public boolean mouseClicked(double x, double y, int button) {
        Window window = Minecraft.getInstance().getWindow();
        return super.mouseClicked((int)(x * window.getGuiScale() / this.customScale), (int)(y * window.getGuiScale() / this.customScale), button);
    }
    @Override
    public boolean mouseReleased(double x, double y, int button) {
        Window window = Minecraft.getInstance().getWindow();
        return super.mouseReleased((int)(x * window.getGuiScale() / this.customScale), (int)(y * window.getGuiScale() / this.customScale), button);
    }
    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dx, double dy) {
        Window window = Minecraft.getInstance().getWindow();
        return super.mouseDragged((int)(mouseX * window.getGuiScale() / this.customScale), (int)(mouseY * window.getGuiScale() / this.customScale), button, dx, dy);
    }
    @Override
    public boolean mouseScrolled(double pMouseX, double pMouseY, double pDelta) {
        Window window = Minecraft.getInstance().getWindow();
        return super.mouseScrolled((int)(pMouseX * window.getGuiScale() / this.customScale), (int)(pMouseY * window.getGuiScale() / this.customScale), pDelta);
    }
    /**
     * 仿史诗战斗技能书 LearnButton 的九宫格按钮，让遗忘按钮与本界面（以及 EF 技能书）风格一致。
     * <p>
     * 贴图取自同一张 skillbook.png：常态取 u=106，悬停/失活取 u=156，v=193，
     * 单块按钮贴图为 45x15，按 sliceWidth=20、sliceHeight=4 做九宫格拉伸。
     */
    protected static class ForgetButton extends Button {
        protected ForgetButton(Button.Builder builder) {
            super(builder);
        }
        @Override
        protected void renderWidget(@NotNull GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
            Minecraft minecraft = Minecraft.getInstance();
            guiGraphics.setColor(1.0F, 1.0F, 1.0F, this.alpha);
            RenderSystem.enableBlend();
            RenderSystem.enableDepthTest();
            int texX = 106;
            if (this.isHoveredOrFocused() || !this.isActive()) {
                texX = 156;
            }
            guiGraphics.pose().pushPose();
            guiGraphics.blitNineSliced(SKILLBOOK_BACKGROUND, this.getX(), this.getY(), this.getWidth(), this.getHeight(), 20, 4, 45, 15, texX, 193);
            guiGraphics.setColor(1.0F, 1.0F, 1.0F, 1.0F);
            guiGraphics.pose().popPose();
            int color = this.getFGColor();
            this.renderString(guiGraphics, minecraft.font, color | Mth.ceil(this.alpha * 255.0F) << 24);
        }
    }
    protected class SkillTooltipList extends ObjectSelectionList<SkillTooltipList.TooltipLine> {
        protected SkillTooltipList(Minecraft minecraft, int width, int height, int y0, int y1, int itemHeight) {
            super(minecraft, width, height, y0, y1, itemHeight);
            this.setRenderBackground(false);
            this.setRenderHeader(false, 0);
            this.setRenderTopAndBottom(false);
        }
        protected void add(FormattedCharSequence tooltip) {
            this.addEntry(new SkillTooltipList.TooltipLine(tooltip));
        }
        protected int getScrollbarPosition() {
            return this.x1 - 6;
        }
        protected class TooltipLine extends ObjectSelectionList.Entry<SkillTooltipList.TooltipLine> {
            protected final FormattedCharSequence tooltip;
            protected TooltipLine(FormattedCharSequence string) {
                this.tooltip = string;
            }
            public void render(GuiGraphics guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean isMouseOver, float partialTicks) {
                guiGraphics.drawString(MaidSkillBookScreen.this.font, this.tooltip, left + 59, top, 0, false);
            }
            public @NotNull Component getNarration() {
                return Component.empty();
            }
        }
    }
}
