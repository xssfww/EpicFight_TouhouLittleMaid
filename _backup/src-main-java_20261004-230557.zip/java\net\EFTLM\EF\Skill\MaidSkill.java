package net.EFTLM.EF.Skill;

import com.github.tartaricacid.touhoulittlemaid.api.event.*;
import com.github.tartaricacid.touhoulittlemaid.entity.passive.EntityMaid;
import net.EFTLM.EF.API.Event.*;
import net.EFTLM.EF.Capability.MaidPatch;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.CreativeModeTab;
import yesman.epicfight.world.capabilities.EpicFightCapabilities;
public abstract class MaidSkill {
    protected final ResourceLocation registryName;
    protected final ResourceLocation iconName;
    protected final CreativeModeTab creativeTab;
    public MaidSkill(MaidSkillBuilder<? extends MaidSkill> builder) {
        this.registryName = builder.registryName;
        this.iconName = builder.iconName;
        this.creativeTab = builder.tab;
    }
    public static MaidSkillBuilder<MaidSkill> createBuilder() {
        return new MaidSkillBuilder<>();
    }
    public void MaidTick(MaidTickEvent event) {
        EntityMaid maid = event.getMaid();
        if (!(maid.level() instanceof ServerLevel)) return;
        MaidPatch<?> patch = EpicFightCapabilities.getEntityPatch(maid, MaidPatch.class);
        if (patch == null) return;
        onMaidTick(event,patch);
    }
    public void MaidAttack(MaidAttackEvent event) {
        EntityMaid maid = event.getMaid();
        if (!(maid.level() instanceof ServerLevel)) return;
        MaidPatch<?> patch = EpicFightCapabilities.getEntityPatch(maid, MaidPatch.class);
        if (patch == null) return;
        onMaidAttack(event,patch);
    }
    public void MaidHurt(MaidHurtEvent event) {
        EntityMaid maid = event.getMaid();
        if (!(maid.level() instanceof ServerLevel)) return;
        MaidPatch<?> patch = EpicFightCapabilities.getEntityPatch(maid, MaidPatch.class);
        if (patch == null) return;
        onMaidHurt(event,patch);
    }
    public void MaidDamage(MaidDamageEvent event) {
        EntityMaid maid = event.getMaid();
        if (!(maid.level() instanceof ServerLevel)) return;
        MaidPatch<?> patch = EpicFightCapabilities.getEntityPatch(maid, MaidPatch.class);
        if (patch == null) return;
        onMaidDamage(event,patch);
    }
    public void MaidDeath(MaidDeathEvent event) {
        EntityMaid maid = event.getMaid();
        if (!(maid.level() instanceof ServerLevel)) return;
        MaidPatch<?> patch = EpicFightCapabilities.getEntityPatch(maid, MaidPatch.class);
        if (patch == null) return;
        onMaidDeath(event,patch);
    }
    public void onHurtTargetPost(MaidHurtTargetEvent.Post event) {
    }
    public void onHurtTargetPre(MaidHurtTargetEvent.Pre event) {
    }
    public void onKillTarget(MaidKilledEvent event) {
    }
    public void onMaidTick(MaidTickEvent event,MaidPatch<?> MaidPatch) {
    }
    public void onMaidAttack(MaidAttackEvent event,MaidPatch<?> MaidPatch) {
    }
    public void onMaidHurt(MaidHurtEvent event,MaidPatch<?> MaidPatch) {
    }
    public void onMaidDamage(MaidDamageEvent event,MaidPatch<?> MaidPatch) {
    }
    public void onMaidDeath(MaidDeathEvent event,MaidPatch<?> MaidPatch) {
    }
    public void onInit(MaidSkillInitEvent event) {
    }
    public void onRemove(MaidChangeItemEvent event) {
        MaidPatch<?> MaidPatch = event.getMaidPatch();
        MaidPatch.removeData(this);
    }
    public boolean canExecute(MaidPatch<?> MaidPatch) {
        return MaidPatch.isFightMode();
    }
    public ResourceLocation getRegistryName() {
        return this.registryName;
    }
    public ResourceLocation getItemIcon() {
        return this.iconName;
    }
    public CreativeModeTab getCreativeTab() {
        return this.creativeTab;
    }
    public MutableComponent getTitle() {
        return Component.translatable(String.format("maid_skill.%s.%s", this.getRegistryName().getNamespace(), this.getRegistryName().getPath()));
    }
    /**
     * 技能描述。{@code MaidPatch} 可为 {@code null}——例如玩家直接用技能书道具打开界面时没有女仆上下文。
     * <p>
     * 开发者可覆写 {@link #getDescArguments(MaidPatch)}，把补丁里的数据按顺序带入 desc 的 {@code %s} 占位符。
     */
    public MutableComponent getDesc(MaidPatch<?> MaidPatch) {
        String Key = String.format("maid_skill.%s.%s.desc", this.getRegistryName().getNamespace(), this.getRegistryName().getPath());
        Object[] Args = this.getDescArguments(MaidPatch);
        if (Args == null || Args.length == 0) {
            return Component.translatable(Key);
        }
        return Component.translatable(Key, Args);
    }
    /**
     * 提供 desc 中 {@code %s} 的实参，顺序需与语言文件里的 {@code %s} 一一对应。
     * <p>
     * 无女仆上下文时 {@code MaidPatch} 为 {@code null}；返回 {@code null} 或空数组表示不做替换。
     * <p>
     * 注意：客户端补丁只同步了已学技能列表，{@code MaidPatch.getDataValue} 携带的技能数据
     * （如 {@code MaidSkillDataKeys.STACK} / {@code ENERGY}）仅在服务端可用。客户端界面请改用
     * 技能实例自身的字段（如 {@code WeaponInnateSkill.getMaxStack()}）。
     */
    public Object[] getDescArguments(MaidPatch<?> MaidPatch) {
        return null;
    }
    public ResourceLocation getIcon() {
        return ResourceLocation.fromNamespaceAndPath(this.getRegistryName().getNamespace(), String.format("textures/gui/skill/%s.png", this.getRegistryName().getPath()));
    }
}
