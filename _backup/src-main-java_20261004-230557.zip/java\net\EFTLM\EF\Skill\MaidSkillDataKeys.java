package net.EFTLM.EF.Skill;

import net.EFTLM.EFTLM;
import net.minecraft.resources.ResourceLocation;

/**
 * 集中的技能数据键注册点，对齐史诗战斗的 {@code SkillDataKeys}。
 * <p>
 * 每个键都有带命名空间的标识（例如 {@code ef_tlm:stack}），序列化时直接以该 id 作为 NBT 键，
 * 因此不会与其他模组的同名键混淆；键 id 重名会在类初始化时直接抛错。
 * <p>
 * 技能类里保留同名的 {@code public static final} 别名指向这里，方便技能代码用简名引用。
 */
public class MaidSkillDataKeys {
    // ---------------- 序列化器（值类型） ----------------
    public static final MaidSkillDataManager.ValueType<Integer> INTEGER = MaidSkillDataManager.ValueType.integer();
    public static final MaidSkillDataManager.ValueType<Float> FLOAT = MaidSkillDataManager.ValueType.floatType();
    public static final MaidSkillDataManager.ValueType<Boolean> BOOLEAN = MaidSkillDataManager.ValueType.booleanType();
    // ---------------- 武器固有技能通用 ----------------
    public static final MaidSkillDataManager.SkillDataKey<Integer> STACK = create("stack", INTEGER);
    public static final MaidSkillDataManager.SkillDataKey<Float> ENERGY = create("energy", FLOAT);
    // ---------------- 爪 ----------------
    public static final MaidSkillDataManager.SkillDataKey<Integer> CLAW_TIME = create("claw_time", INTEGER);
    // ---------------- 村正 / 斩切模式 ----------------
    public static final MaidSkillDataManager.SkillDataKey<Boolean> MURASAMA_ZANSETSU = create("murasama_zansetsu", BOOLEAN);
    public static final MaidSkillDataManager.SkillDataKey<Integer> MURASAMA_ZANSETSU_DELAY = create("murasama_zansetsu_delay", INTEGER);
    public static final MaidSkillDataManager.SkillDataKey<Integer> MURASAMA_ZANSETSU_INDEX = create("murasama_zansetsu_index", INTEGER);
    // ---------------- HF Blade ----------------
    public static final MaidSkillDataManager.SkillDataKey<Boolean> HF_BLADE_ZANSETSU = create("hf_blade_zansetsu", BOOLEAN);
    public static final MaidSkillDataManager.SkillDataKey<Integer> HF_BLADE_ZANSETSU_DELAY = create("hf_blade_zansetsu_delay", INTEGER);
    public static final MaidSkillDataManager.SkillDataKey<Integer> HF_BLADE_ZANSETSU_INDEX = create("hf_blade_zansetsu_index", INTEGER);
    // ---------------- 余火（矛） ----------------
    public static final MaidSkillDataManager.SkillDataKey<Integer> MEEN_CHARGING_TIME = create("meen_charging_time", INTEGER);
    // ---------------- 阎魔刀（幻影剑） ----------------
    /** 无门阵的存续时间；同时作为再次召唤无门阵的冷却（对齐 EFN：600 tick）。 */
    public static final MaidSkillDataManager.SkillDataKey<Integer> YAMATO_FORMATION_TIME = create("yamato_formation_time", INTEGER);
    /** 急袭幻影剑的冷却。 */
    public static final MaidSkillDataManager.SkillDataKey<Integer> YAMATO_BLAST_COOLDOWN = create("yamato_blast_cooldown", INTEGER);
    /** 暴雨幻影剑的冷却。 */
    public static final MaidSkillDataManager.SkillDataKey<Integer> YAMATO_SWORD_RAIN_COOLDOWN = create("yamato_sword_rain_cooldown", INTEGER);
    /** 五月雨的冷却。 */
    public static final MaidSkillDataManager.SkillDataKey<Integer> YAMATO_HEAVY_RAIN_COOLDOWN = create("yamato_heavy_rain_cooldown", INTEGER);
    // ---------------- 刀光剑影（格挡） ----------------
    public static final MaidSkillDataManager.SkillDataKey<Float> BLADE_CLASH_PENALTY = create("blade_clash_penalty", FLOAT);
    public static final MaidSkillDataManager.SkillDataKey<Integer> BLADE_CLASH_RESTORE_COUNTER = create("blade_clash_restore_counter", INTEGER);
    // ---------------- 灵动步伐（闪避） ----------------
    public static final MaidSkillDataManager.SkillDataKey<Integer> STEP_RESTORE_COUNTER = create("step_restore_counter", INTEGER);
    // ==================== 对附属开发者开放的注册入口 ====================
    /**
     * 注册一个技能数据键。
     * <p>
     * 键 id 为 {@code <namespace>:<path>}，会参与 {@code MaidPatch.serializeNBT()} /
     * {@code deserializeNBT()}，即同步到客户端并写入存档。因此 {@code namespace} 必须填
     * <b>你自己的模组 id</b>，不要用 {@code ef_tlm}，否则会与本模组内置键撞 id 并在类初始化时抛错。
     * <p>
     * 用法：
     * <pre>{@code
     * public static final MaidSkillDataManager.SkillDataKey<Integer> MY_COUNTER =
     *         MaidSkillDataKeys.create("my_mod", "counter", MaidSkillDataKeys.INTEGER);
     *
     * // 技能里
     * event.registerData(this, MY_COUNTER);        // 用默认值（序列化器零值）
     * event.registerData(this, MY_COUNTER, 100);   // 或显式指定初值
     * Integer value = patch.getDataValue(this, MY_COUNTER);
     * }</pre>
     *
     * @param namespace 你的模组 id
     * @param path      键名，需在该命名空间内唯一
     * @param valueType 序列化器：{@link #INTEGER} / {@link #FLOAT} / {@link #BOOLEAN}
     */
    public static <V> MaidSkillDataManager.SkillDataKey<V> create(String namespace, String path, MaidSkillDataManager.ValueType<V> valueType) {
        return create(ResourceLocation.fromNamespaceAndPath(namespace, path), valueType);
    }
    /** 用完整 {@link ResourceLocation} 指定键 id；默认值取序列化器的零值。 */
    public static <V> MaidSkillDataManager.SkillDataKey<V> create(ResourceLocation id, MaidSkillDataManager.ValueType<V> valueType) {
        return MaidSkillDataManager.SkillDataKey.createDataKey(id, valueType);
    }
    /** 同上，并显式指定初值（需要非零/非 false 起始值时用它）。 */
    public static <V> MaidSkillDataManager.SkillDataKey<V> create(ResourceLocation id, MaidSkillDataManager.ValueType<V> valueType, V defaultValue) {
        return MaidSkillDataManager.SkillDataKey.createDataKey(id, valueType, defaultValue);
    }
    /** 本模组内置键用：固定使用 {@code ef_tlm} 命名空间。 */
    private static <V> MaidSkillDataManager.SkillDataKey<V> create(String path, MaidSkillDataManager.ValueType<V> valueType) {
        return create(EFTLM.MODID, path, valueType);
    }
}
